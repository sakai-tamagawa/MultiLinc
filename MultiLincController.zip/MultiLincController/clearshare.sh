#!/bin/sh

bin/clearshare ml_share.run
